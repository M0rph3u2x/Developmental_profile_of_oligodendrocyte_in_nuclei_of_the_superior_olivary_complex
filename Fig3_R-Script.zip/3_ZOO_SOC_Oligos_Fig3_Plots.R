#!/usr/bin/env Rscript --vanilla

#-----------------------------
# Author
#-----------------------------

# The script was written by Tjard Bergmann (2023) and is not licensed.
# Everyone is free to use or edit it under the rules of creative commons (CC BY).

# University of Veterinary Medicine Hannover
# Institute of Zoology, AG Felmy (Neurobiology)
# Website: https://www.tiho-hannover.de/kliniken-institute/institute/institut-fuer-zoologie/arbeitsgruppen/neurobiologie/ag-felmy

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------

#-----------------------------
# Reference
#-----------------------------

#Please cite the following manuscript when using this script:

#Developmental profile of oligodendrocyte arrangement, identification and morphology 
#in nuclei of the superior olivary complex  

#-----------------------------
# Description
#-----------------------------

# This R-script processes Oligodendrocyte SOC brain slice cell data
# from ImageJ data (Combined_ImageJ-data + ROI-data) and calculates
# cell number per slice, nucleus area and cell density.The resulting
# data will be saved in an xlsx file "Fig3_Raw_data" (including separated 
# data sheets for each nucleus of interest) and an overview plot 
# "Fig3_Overview.pdf".

#-----------------------------
# Software dependencies
#-----------------------------

#The script must be executed within the Editor: RStudio
#Source: https://posit.co/

#This script is dependent on the following functions:

#cowplot   : function (plot_grid) creates multiplot figures
#dplyr     : mutate
#EnvStats  : stat_n_text
#ggplot2   : ggplot
#pacman    : Package manager (pacman::p_load())
#readxl    : Read xlsx data
#rstudioapi: Get path from RStudio (function: getSourceEditorContext()$path)
#stringr   : str_sub
#writexl   : write xlsx file (write_xlsx)
    
#-----------------------------
# Guide
#-----------------------------

# To successfully run the program you need to:

# 1) The program is dependent on two input files (Combined_ImageJ-data.csv, ROI-data.csv).
#    The files are zipped in "input_data.zip" on github (https://github.com/M0rph3u2x/Developmental_profile_of_oligodendrocyte_in_nuclei_of_the_superior_olivary_complex/upload/main).
#    Both of these files where created with ImageJ (https://imagej.net/).
#    Combined_ImageJ-data.csv -> Holds all cell coordination data
#    ROI-data.csv             -> Holds the ROI coordinate data for all SOC nuclei
#    Both files must be placed in the same folder as this script!

# 2) Press Ctr+A, then Ctrl+Enter to execute the program

# 3) The R script will process the data, create a new output folder "fig3_output"  
#    and store the resulting tables (Fig3_Raw_data.xlsx, Fig3_Overview.pdf) inside it.

#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
# Load necessary libraries -----------------------------------------------------
#-------------------------------------------------------------------------------

# Define necessary package manager
packages <- c("pacman")

# Install package manager if not yet installed
installed_packages <- packages %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  install.packages(packages[!installed_packages])
}


#Install and/or load all necessary packages via package manager "pacman"
pacman::p_load(cowplot,     # function (plot_grid) creates multiplot figures
               dplyr,       # mutate
               EnvStats,    # stat_n_text
               ggplot2,     # ggplot
               readxl,      # Read xlsx data
               rstudioapi,  # Get path from RStudio (function: getSourceEditorContext()$path)  
               stringr,     # str_sub 
               writexl)     # write xlsx file (write_xlsx)      

#-------------------------------------------------------------------------------
# Setup directory where the program is running ---------------------------------
#-------------------------------------------------------------------------------

#Create path to data
R.Directory = sub(pattern = "(.*/).*\\..*$", replacement = "\\1", getSourceEditorContext()$path)

#Create shortcut to main path (Fullpath connects R.directory with follow up folders)
FullPath = function(FileName){ return( paste(R.Directory,FileName,sep="") ) }

# Set the working directory to the folder where the program is running
setwd(R.Directory)

#Submit working directory to variable
work_path <- getwd()

#Identify main input folder
inpath <- FullPath("fig3_input")

#Create main output folder
outpath <- FullPath("fig3_output")
dir.create(outpath, showWarnings = FALSE)

#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#Create sheets in xlsx file (tuned for cell dataset) ---------------------------
#-------------------------------------------------------------------------------

create_xlsx_sheet <- function(sheet.data){
  
  #Create two empty columns with the length of data
  empty.col <- rep("",length(sheet.data[,1]))
  empty.col <- data.frame("Empty1"=empty.col,"Empty2"=empty.col)
  
  #Combine empty columns with data columns
  sheet.data <- cbind(empty.col,sheet.data)
  sheet      <- list(sheet = sheet.data)
  return(sheet)
}

#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#Calculate ROI density ---------------------------------------------------------
#-------------------------------------------------------------------------------

#Load "Combined_ImageJ-data"
csv_path        <- file.path(inpath, "Combined_ImageJ-data.csv")
all_imagej_data <- read.csv(file=csv_path) 

#Pool MSO-Data
all_imagej_data$Region[all_imagej_data$Region=="MSO_lateral"] <- "MSO"
all_imagej_data$Region[all_imagej_data$Region=="MSO_medial"]  <- "MSO"
all_imagej_data$Region[all_imagej_data$Region=="MSO_mitte"]   <- "MSO"

#Load ROI_data (nucleus border data)
csv_path <- file.path(inpath, "ROI-data.csv")
roi_data <- read.csv(file=csv_path) 

#Pool MSO-Data
roi_data$Region[roi_data$Region=="MSO_lateral"] <- "MSO"
roi_data$Region[roi_data$Region=="MSO_medial"]  <- "MSO"
roi_data$Region[roi_data$Region=="MSO_mitte"]   <- "MSO"

#Get unique regions and age groups
Regions  <- unique(roi_data$Region)
Ages     <- unique(roi_data$Age)

#Initiate new dataframe
reg_dens <- data.frame(Slice                 =integer(),
                       Region                =integer(),
                       Age                   =integer(),
                       Cell_Nr               =integer(),
                       ROI_Area_Pixel        =integer(),
                       Region_Density_Pixel  =integer())

#Combine data from "Combined_ImageJ-data" and "ROI_data"
#Count cells per nucleus and calculate nucleus density (cellnumber/Nucleus Area)
for(reg in 1:length(Regions)){#reg<-1
  for(age in 1:length(Ages)){#age<-1
    subset            <- roi_data[roi_data$Region == Regions[reg] & roi_data$Age == Ages[age], ]
    subset_slicename <- unique(subset$Slice)
    for(name in 1:length(subset_slicename)){#name<-1
      slice_name <- subset[subset$Slice == subset_slicename[name], 'Slice']
      cell_nr    <- sum(length(all_imagej_data[all_imagej_data$Region == Regions[reg] & all_imagej_data$Age == Ages[age] & all_imagej_data$Slice_Name == slice_name, 'Area']))
      area_roi   <- sum(subset[subset$Slice == subset_slicename[name], 'Area'])
      density    <- cell_nr/area_roi
      data_temp  <- data.frame(Slice=slice_name,Region=Regions[reg],Age=Ages[age],Cell_Nr=cell_nr,ROI_Area_Pixel=area_roi,Region_Density_Pixel=density)
      reg_dens   <- rbind(reg_dens,data_temp)
    }
  }
}

#Convert pixel to µm² (Area)
reg_dens$ROI_Area_µm = round(reg_dens$ROI_Area_Pixel * 0.586 * 0.586, digits = 2) #Area µm²

#Calculate density in µm
reg_dens$Region_Density_µm = reg_dens$Cell_Nr/reg_dens$ROI_Area_µm

#Convert µm to mm
reg_dens$ROI_Area_mm       = reg_dens$ROI_Area_µm       /1000000 #Area mm²
reg_dens$Region_Density_mm = reg_dens$Cell_Nr/reg_dens$ROI_Area_mm

#Format age column (string to numeric value)
reg_dens$Age <- as.numeric(str_sub(reg_dens$Age, start=2,end=3))

#Erase duplicate rows (necessary because MSO nucleus data are combined)
reg_dens <- distinct(reg_dens)

#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#Create sorted xlsx table of ROI density data ----------------------------------
#-------------------------------------------------------------------------------

#Sort by slice
reg_dens <- reg_dens[order(reg_dens$Slice,reg_dens$Age),]

#Create sheets
sheets <- list("All_data" = reg_dens)

#Define sheets
region <- c("MNTB","MSO","LSO_VGlut+","LSO_VGlut-","Kontrolle")

for(reg in region){
  sheet.data <- reg_dens[reg_dens$Region==reg,]
  sheet      <- create_xlsx_sheet(sheet.data)
  sheets     <- c(sheets,sheet)
}

#Attach sheet names to xlsx-sheets
names(sheets) <- c("All_data","MNTB","MSO","LSO_VGlut+","LSO_VGlut-","Kontrolle")

#Output directory
path <- paste(outpath,"Fig3_Raw_data.xlsx",sep="/")

#Create xlsx summary table (contains cummulative data of all processed MNTBs)
write_xlsx(sheets, path)

#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
#Plot the Fig3 data ------------------------------------------------------------
#-------------------------------------------------------------------------------

#Plot1: cell number/section
plot1 <-
  reg_dens %>%
  mutate(Region = factor(Region, levels=c("MNTB","MSO","LSO_VGlut+","LSO_VGlut-","Kontrolle"))) %>%
  ggplot(aes(x = Age, y = Cell_Nr)) +
  geom_jitter(shape=1,position=position_dodge(0.75), aes(colour=Region), alpha=0.9, show.legend = FALSE) +
  stat_n_text(angle = 90,size=3)+
  facet_wrap( ~ Region, scales="free_y",ncol=1, nrow=5)+
  stat_summary(fun=median, geom="point", shape=16,size=3, color="red")+
  geom_point(aes(color = Region), alpha = 0.9, show.legend = FALSE) +
  theme_bw() +
  labs(title = 'cell number/section',
       x = 'postnatal age (days)',
       y = 'cell number / section') +
  scale_x_continuous(breaks=c(5,7,10,12,14,17,21,36,54), labels= c("5","7","10","12","14","17","21","34","54"))+
  theme(axis.text.x = element_text(angle = 90))

#Plot2: area size
plot2 <-
  reg_dens %>%
  mutate(Region = factor(Region, levels=c("MNTB","MSO","LSO_VGlut+","LSO_VGlut-","Kontrolle"))) %>%
  ggplot(aes(x = Age, y = ROI_Area_mm)) +
  geom_jitter(shape=1,position=position_dodge(0.75), aes(colour=Region), alpha=0.9, show.legend = FALSE) +
  stat_n_text(angle = 90,size=3)+
  facet_wrap( ~ Region, scales="free_y",ncol=1, nrow=5)+
  stat_summary(fun=median, geom="point", shape=16,size=3, color="red")+
  geom_point(aes(color = Region), alpha = 0.9, show.legend = FALSE) +
  theme_bw() +
  labs(title = 'area size',
       x = 'postnatal age (days)',
       y = 'area size [mm²]') +
  scale_x_continuous(breaks=c(5,7,10,12,14,17,21,36,54), labels= c("5","7","10","12","14","17","21","34","54"))+
  theme(axis.text.x = element_text(angle = 90))

#Plot3: density
plot3 <-
  reg_dens %>%
  mutate(Region = factor(Region, levels=c("MNTB","MSO","LSO_VGlut+","LSO_VGlut-","Kontrolle"))) %>%
  ggplot(aes(x = Age, y = Region_Density_mm)) +
  geom_jitter(shape=1,position=position_dodge(0.75), aes(colour=Region), alpha=0.9, show.legend = FALSE) +
  stat_n_text(angle = 90,size=3)+
  facet_wrap( ~ Region, scales="free_y",ncol=1, nrow=5)+
  stat_summary(fun=median, geom="point", shape=16,size=3, color="red")+
  geom_point(aes(color = Region), alpha = 0.9, show.legend = FALSE) +
  theme_bw() +
  labs(title = 'density',
       x = 'postnatal age (days)',
       y = 'density ((sum cells/section) / region size [mm²])') +
  scale_x_continuous(breaks=c(5,7,10,12,14,17,21,36,54), labels= c("5","7","10","12","14","17","21","34","54"))+
  theme(axis.text.x = element_text(angle = 90))

#Plot multiple plots in one pdf as cumulative plot
plot_grid(plot1, plot2, plot3, 
          labels = c("A", "B", "c"),
          ncol = 3, nrow = 1)
png_path <- file.path(outpath, "Fig3_Overview.pdf")
ggsave(png_path, dpi=300, width=14, height=16)

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------